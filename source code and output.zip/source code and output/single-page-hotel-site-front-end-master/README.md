# single-page-hotel-site-front-end
It is a single page hotel website front end design made using HTML,CSS and Bootstarp.

![project home page](https://raw.githubusercontent.com/koushil-mankali/single-page-hotel-site-front-end/39150f48403ff9d102bdccd21d423b859de35ebf/MK_Hotels.png)
